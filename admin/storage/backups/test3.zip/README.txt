SSO Authentication System Backup
===================================

Created: 2025-10-12 13:34:24
Created by: admin@psu.ac.th
Version: 3.0.0
Type: full
Description: 

This backup contains client configurations, admin users, and system settings.
Use the SSO Admin Panel to restore this backup.
