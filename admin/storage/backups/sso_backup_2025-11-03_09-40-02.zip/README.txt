SSO Authentication System Backup
===================================

Created: 2025-11-03 09:40:02
Created by: admin@psu.ac.th
Version: 3.0.0
Type: full
Description: 

This backup contains client configurations, admin users, and system settings.
Use the SSO-Authen Admin Panel to restore this backup.
